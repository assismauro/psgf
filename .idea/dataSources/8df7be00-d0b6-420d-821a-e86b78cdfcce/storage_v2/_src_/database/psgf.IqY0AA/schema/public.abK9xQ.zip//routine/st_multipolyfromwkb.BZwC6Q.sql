create function st_multipolyfromwkb(bytea) returns geometry
    immutable
    strict
    parallel safe
    language sql
as
$$
SELECT CASE WHEN public.geometrytype(public.ST_GeomFromWKB($1)) = 'MULTIPOLYGON'
	THEN public.ST_GeomFromWKB($1)
	ELSE NULL END

$$;

alter function st_multipolyfromwkb(bytea) owner to psgf;

