create function st_multipointfromtext(text) returns geometry
    immutable
    strict
    parallel safe
    language sql
as
$$
SELECT public.ST_MPointFromText($1)
$$;

alter function st_multipointfromtext(text) owner to psgf;

