create function addgeometrycolumn(schema_name character varying, table_name character varying, column_name character varying, new_srid integer, new_type character varying, new_dim integer, use_typmod boolean DEFAULT true) returns text
    stable
    strict
    language plpgsql
as
$$
DECLARE
	ret  text;
BEGIN
	SELECT public.AddGeometryColumn('',$1,$2,$3,$4,$5,$6,$7) into ret;
	RETURN ret;
END;
$$;

comment on function addgeometrycolumn(varchar, varchar, varchar, integer, varchar, integer, boolean) is 'args: schema_name, table_name, column_name, srid, type, dimension, use_typmod=true - Adds a geometry column to an existing table.';

alter function addgeometrycolumn(varchar, varchar, varchar, integer, varchar, integer, boolean) owner to psgf;

