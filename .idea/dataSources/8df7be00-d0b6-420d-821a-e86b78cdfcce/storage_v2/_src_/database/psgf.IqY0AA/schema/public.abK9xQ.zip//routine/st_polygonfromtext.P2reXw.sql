create function st_polygonfromtext(text) returns geometry
    immutable
    strict
    parallel safe
    language sql
as
$$
SELECT public.ST_PolyFromText($1)
$$;

alter function st_polygonfromtext(text) owner to psgf;

