create function st_asgeojson(text) returns text
    immutable
    strict
    parallel safe
    language sql
as
$$
SELECT public.ST_AsGeoJson($1::public.geometry, 9, 0);
$$;

alter function st_asgeojson(text) owner to psgf;

