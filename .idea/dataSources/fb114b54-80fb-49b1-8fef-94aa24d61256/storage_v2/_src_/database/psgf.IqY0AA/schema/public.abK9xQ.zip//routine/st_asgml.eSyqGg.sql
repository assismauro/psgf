create function st_asgml(version integer, geom geometry, maxdecimaldigits integer DEFAULT 15, options integer DEFAULT 0, nprefix text DEFAULT NULL::text, id text DEFAULT NULL::text) returns text
    immutable
    parallel safe
    language sql
as
$$
SELECT public._ST_AsGML($1, $2, $3, $4, $5, $6);
$$;

alter function st_asgml(integer, geometry, integer, integer, text, text) owner to postgres;

