create function postgis_scripts_build_date() returns text
    immutable
    language sql
as
$$
SELECT '2020-02-22 21:23:15'::text AS version
$$;

comment on function postgis_scripts_build_date() is 'Returns build date of the PostGIS scripts.';

alter function postgis_scripts_build_date() owner to postgres;

