create function st_forcepolygonccw(geometry) returns geometry
    immutable
    strict
    parallel safe
    language sql
as
$$
SELECT public.ST_Reverse(public.ST_ForcePolygonCW($1))
$$;

comment on function st_forcepolygonccw(geometry) is 'args: geom - Orients all exterior rings counter-clockwise and all interior rings clockwise.';

alter function st_forcepolygonccw(geometry) owner to postgres;

